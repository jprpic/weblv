INSERT INTO sensors (id, room, created_at, updated_at)
VALUES ('1', 'Dnevni', '2022-02-23 21:05:03', '2022-02-23 21:05:03');
INSERT INTO sensors (id, room, created_at, updated_at)
VALUES ('2', 'Ured', '2022-02-23 21:41:21', '2022-02-23 21:41:21');
