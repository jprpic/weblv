INSERT INTO users (id, first_name, last_name, OIB)
VALUES ('1', 'Jakov', 'Prpic', '123456789');
INSERT INTO users (id, first_name, last_name, OIB)
VALUES ('2', 'Borna', 'Belja', '987654321');
INSERT INTO users (id, first_name, last_name, OIB)
VALUES ('3', 'Zvonimir', 'Medoslav', '123123123');
