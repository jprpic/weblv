INSERT INTO cars (id, name, color, horsepower)
VALUES ('1', 'Mitsubishi EVO XIII', 'red', '300');
INSERT INTO cars (id, name, color, horsepower)
VALUES ('2', 'Nissan Skyline', 'blue', '300');
INSERT INTO cars (id, name, color, horsepower)
VALUES ('3', 'Suzuki Impreza', 'blue', '300');
