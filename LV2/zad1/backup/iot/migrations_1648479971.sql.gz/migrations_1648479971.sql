INSERT INTO migrations (id, migration, batch)
VALUES ('1', '2022_02_22_112350_create_sensors_table', '1');
INSERT INTO migrations (id, migration, batch)
VALUES ('2', '2022_02_22_112417_create_sensor_entries_table', '1');
