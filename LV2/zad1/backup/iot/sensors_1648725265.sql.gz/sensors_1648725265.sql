INSERT INTO sensors (id, room, created_at, updated_at)
VALUES ('1', 'Dnevni', '2022-03-18 15:16:17', '2022-03-18 15:16:17');
INSERT INTO sensors (id, room, created_at, updated_at)
VALUES ('2', 'Kuhinja', '2022-03-18 15:16:17', '2022-03-18 15:16:17');
INSERT INTO sensors (id, room, created_at, updated_at)
VALUES ('3', 'Soba', '2022-03-18 15:16:17', '2022-03-18 15:16:17');
