INSERT INTO migrations (id, migration, batch)
VALUES ('50', '2022_02_22_112350_create_sensors_table', '1');
INSERT INTO migrations (id, migration, batch)
VALUES ('51', '2022_02_22_112417_create_sensor_entries_table', '1');
